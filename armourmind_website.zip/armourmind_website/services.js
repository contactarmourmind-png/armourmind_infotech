const express = require("express");
const cors = require("cors");
const path = require("path");

const app = express();

app.use(cors());
app.use(express.json());

// Serve static files
app.use(express.static(__dirname));

// Chat API
app.post("/api/chat", (req, res) => {

    const msg = req.body.message?.toLowerCase() || "";
    let reply = "Please contact our enterprise security team.";

    if (msg.includes("price")) {
        reply = "Pricing depends on enterprise scope. Would you like a demo?";
    } 
    else if (msg.includes("demo")) {
        reply = "You can request a demo from the Demo page.";
    } 
    else if (msg.includes("features")) {
        reply = "ArmourMind provides autonomous reconnaissance, AI exploit simulation, and adaptive defense automation.";
    } 
    else if (msg.includes("hello") || msg.includes("hi")) {
        reply = "Hello. How can I assist you regarding ArmourMind?";
    }

    res.json({ reply });
});

// Start server
const PORT = 5000;

app.listen(PORT, () => {
    console.log("Server running at http://localhost:5000");
});