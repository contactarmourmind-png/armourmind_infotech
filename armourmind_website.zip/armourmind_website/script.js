function openModal() {
    document.getElementById("modal").style.display = "block";
}

function closeModal() {
    document.getElementById("modal").style.display = "none";
}

function toggleChat() {
    const chat = document.getElementById("chatWindow");
    chat.style.display = chat.style.display === "block" ? "none" : "block";
}