// ===============================
// ARMOURMIND MAIN JS (PRODUCTION)
// ===============================

// -------- NAVBAR TOGGLE --------
function toggleMenu() {
    const nav = document.getElementById("navLinks");
    if (nav) nav.classList.toggle("active");
}

// -------- CHAT TOGGLE --------
function toggleChat() {
    const chatbox = document.getElementById("chatbox");
    if (chatbox) chatbox.classList.toggle("active");
}

// -------- DOM READY --------
document.addEventListener("DOMContentLoaded", function () {

    const input = document.getElementById("userInput");

    if (input) {
        input.addEventListener("keypress", function (e) {
            if (e.key === "Enter") {
                sendMessage();
            }
        });
    }
});

// -------- SEND MESSAGE --------
async function sendMessage() {

    const input = document.getElementById("userInput");
    const messages = document.getElementById("chatMessages");

    if (!input || !messages) return;

    const userText = input.value.trim();
    if (!userText) return;

    appendMessage("user", userText);
    input.value = "";

    showTyping();

    try {

        const response = await fetch("http://localhost:5000/api/ai", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ message: userText })
        });

        if (!response.ok) {
            throw new Error("Server error");
        }

        const data = await response.json();

        removeTyping();

        if (data.reply) {
            appendMessage("bot", data.reply);
        } else {
            appendMessage("bot", "Unexpected response received.");
        }

        detectLead(userText);

    } catch (error) {
        removeTyping();
        appendMessage("bot", "System temporarily unavailable. Please contact our enterprise team.");
        console.error("Chat error:", error);
    }
}

// -------- APPEND MESSAGE --------
function appendMessage(type, text) {

    const messages = document.getElementById("chatMessages");

    if (!messages) return;

    const messageDiv = document.createElement("div");
    messageDiv.className = type === "user" ? "user-message" : "bot-message";

    messageDiv.innerText = text;

    messages.appendChild(messageDiv);

    messages.scrollTop = messages.scrollHeight;
}

// -------- TYPING INDICATOR --------
function showTyping() {

    const messages = document.getElementById("chatMessages");

    if (!messages) return;

    const typingDiv = document.createElement("div");
    typingDiv.className = "bot-message";
    typingDiv.id = "typing-indicator";

    typingDiv.innerHTML = `
        ArmourMind AI is analyzing
        <span class="dot">.</span>
        <span class="dot">.</span>
        <span class="dot">.</span>
    `;

    messages.appendChild(typingDiv);
    messages.scrollTop = messages.scrollHeight;
}

function removeTyping() {
    const typing = document.getElementById("typing-indicator");
    if (typing) typing.remove();
}

// -------- LEAD DETECTION --------
function detectLead(message) {

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (emailRegex.test(message)) {
        appendMessage(
            "bot",
            "Thank you. Our enterprise security team will contact you shortly."
        );
    }
}