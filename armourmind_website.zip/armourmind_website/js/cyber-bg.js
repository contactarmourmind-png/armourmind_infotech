const canvas = document.getElementById("cyberCanvas");
const ctx = canvas.getContext("2d");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let lines = [];
let nodes = [];

const lineCount = 30;
const nodeCount = 40;

// Create fast moving lines
for (let i = 0; i < lineCount; i++) {
    lines.push({
        x: Math.random() * canvas.width,
        speed: 6 + Math.random() * 6,
        width: 1 + Math.random() * 2
    });
}

// Create glowing nodes
for (let i = 0; i < nodeCount; i++) {
    nodes.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: 2 + Math.random() * 3,
        speed: 4 + Math.random() * 4
    });
}

function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw fast vertical lines
    lines.forEach(line => {
        ctx.beginPath();
        ctx.moveTo(line.x, 0);
        ctx.lineTo(line.x, canvas.height);
        ctx.strokeStyle = "rgba(0,255,255,0.15)";
        ctx.lineWidth = line.width;
        ctx.stroke();

        line.x -= line.speed;

        if (line.x < 0) {
            line.x = canvas.width;
        }
    });

    // Draw moving nodes
    nodes.forEach(node => {
        ctx.beginPath();
        ctx.arc(node.x, node.y, node.size, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(0,255,255,0.7)";
        ctx.fill();

        node.y += node.speed;

        if (node.y > canvas.height) {
            node.y = 0;
            node.x = Math.random() * canvas.width;
        }
    });

    requestAnimationFrame(animate);
}

animate();

window.addEventListener("resize", () => {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
});